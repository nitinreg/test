﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using System.Reflection;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel;

namespace AutomationCore.Utilities
{
    public class Utilities
    {
        Excel.Application app;
        Excel.Workbook wb;
        Excel.Worksheet wk;
        
        public void WriteToExcel(string data)
        {
            app = new Excel.Application();
            app.Visible = true;
            wb = app.Workbooks.Add();
            //wb = new Excel.Workbook();
            //wk = new Excel.Worksheet();
            
            wk = wb.Worksheets[1];
            wk.Name = "TestDirectFlight";
            wk.Cells[1,1] = data;
            string currentPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            string parentPath = Path.GetFullPath(System.IO.Path.Combine(currentPath, "..\\..\\.."));
            wb.SaveAs(@parentPath + "\\" + DateTime.Now.ToString("MM_dd_yyyy_hh_mm") + ".xls", Excel.XlFileFormat.xlWorkbookNormal); //get path from config
            
            wb.Close();
            app.Quit();
        }
    }
}
