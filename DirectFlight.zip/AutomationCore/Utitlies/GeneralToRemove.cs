﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutomationCore.Utitlies
{
    class GeneralToRemove
    {
        // Find the text input element by its name
        //IWebElement queryElement = driver.FindElement(By.Name("q"));
        /*                                       By.Id("q"));
         *                                       By.Xpath("//input/div/h1"));
                                                 By.CssSelector("#funds span.list.names"));
                                                 By.TagName("iframe")
                                                 By.LinkText("")
                                                 By.PartialLinkText("")
        */


        /*
        // ------------------ SELECT  control -----------------------
        IWebElement select = driver.FindElement(By.TagName("select"));  //OR by id etc.
        IList<IWebElement> allOptions = select.FindElements(By.TagName("option"));
            foreach (IWebElement option in allOptions)
            {
                Console.WriteLine("Value is: " + option.GetAttribute("value"));
                option.Click();
            }
        */


        /*
        // -----     Moving Between Windows and Frames  ----- 
        driver.SwitchTo().Window("windowName");

            //OR  pass window handle 

            foreach (string handle in driver.WindowHandles)
            {
                driver.SwitchTo().Window(handle);
             }

            // ----------Switch frames (OR Iframes) ---------------
            driver.SwitchTo().Frame("frameName");
        */

        /*
        *  //---  popup, dialogs /alerts ---- 

        Alert alert = driver.SwitchTo().Alert();

        // this will return you curerntly opened alert and that you could use to response to it
        */

        /*
    Cookie cookie = new Cookie("key", "value");
    driver.Manage().Cookies.AddCookie(cookie);

        // And now output all the available cookies for the current URL
        */

        //document.getElementById("demo").innerHTML = 5 + 6;
        //document.write(5 + 6);


}
}
