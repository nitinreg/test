﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using AutomationCore.Enums;

namespace AutomationCore.Pages
{
    public class ResultsPage
    {
        IWebDriver driver;
        public ResultsPage(Browsers browser)
        {
            driver = Driver.GetDriver(browser);
        }

        public string[] CheapestPriceFlightDetails()
        {
            var cheapestPriceElement = driver.FindElement(By.CssSelector("li[class = 'cheapest resp-tab-item resp-tab-active']"));
            return cheapestPriceElement.Text.Split(new string[] { "\r\n" }, StringSplitOptions.None);            
        }

        public IList<IWebElement> AllFlightDetails()
        {
           var allFlights = driver.FindElements(By.XPath("//*[@class='resultlist-item']"));
           return allFlights;
        }

        public string[] GetMinimumPriceFlightDetails()
        {
            var allFlights = AllFlightDetails();
            var minPriceFlightRecord = allFlights[0];
            var minPriceFlightArray = allFlights[0].Text.Split(new string[] { "\r\n" }, StringSplitOptions.None);
            var minPrice = Convert.ToDecimal(minPriceFlightArray[minPriceFlightArray.Length - 3].Substring(1));
            
            foreach (IWebElement flightdetail in allFlights)
            {
                //Console.WriteLine(flightdetail.Text);
                var flightDetails = flightdetail.Text.Split(new string[] {"\r\n" }, StringSplitOptions.None);
                var price = Convert.ToDecimal(flightDetails[flightDetails.Length -3].Substring(1));

                if (price < minPrice)
                {
                    minPrice = price;
                    minPriceFlightRecord = flightdetail;
                }
            }
            return minPriceFlightRecord.Text.Split(new string[] { "\r\n" }, StringSplitOptions.None);
        }

        public void BookCheapestFlight()
        {
            driver.FindElement(By.XPath("//*[@id='resultlist']/div[1]/div/div[2]/div/div[2]/div/a")).Click();
        }

        public void PrintOnPage(string text)
        {
            var str = "document.write('<h1>" + text + "</h1>')";

            //IJavaScriptExecutor js = (IJavaScriptExecutor)driver;

            //js.ExecuteScript(str);

            //js.ExecuteScript("document.Write(" + text + "");
            
            //js.ExecuteScript("document.getElementById('flights_calendar_return_inp_org').value='2018-10-12'");
        }
    }
}
