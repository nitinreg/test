﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace AutomationCore.Pages
{
    public static class Pages
    {
        //private static T GetPage<T>() where T : new()
        //{
        //    var page = new T();
        //    PageFactory.InitElements(Driver, page);
        //    return page;
        //}

        //public static HomePage Home
        //{
        //    get { return GetPage<HomePage>(); }
        //}

        /*
        public static MyMembershipPage MyMembership
        {
            get { return GetPage<MyMembershipPage>(); }
        }

        public static EditProfilePage EditProfile
        {
            get { return GetPage<EditProfilePage>(); }
        }
        */
    }
}
