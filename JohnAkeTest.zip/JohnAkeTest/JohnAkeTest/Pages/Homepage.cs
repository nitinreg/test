﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System.Configuration;
using OpenQA.Selenium.Support.UI;
using JohnAkeTest.Support.HelperObjects;

namespace JohnAkeTest.Pages
{
    public class Homepage
    {
        private IWebDriver _driver;

        private static string _url = ConfigurationManager.AppSettings["SiteUrl"];
        public Homepage(IWebDriver driver)
        {
            _driver = driver;
            _driver.Navigate().GoToUrl(_url);
            PageFactory.InitElements(_driver, this);
        }

        [FindsBy(How = How.Id, Using = "SearchBtn")]
        private IWebElement SearchFlightBtn { get; set; }

        [FindsBy(How = How.Id, Using = "FromTag")]
        private IWebElement FromTxtBox { get; set; }

        [FindsBy(How = How.Id, Using = "ToTag")]
        private IWebElement ToTxtBox { get; set; }

        [FindsBy(How = How.Id, Using = "DepartDate")]
        private IWebElement DepartureDateTxtBox { get; set; }

        [FindsBy(How = How.Id, Using = "Adults")]
        private IWebElement AdultsDropdown { get; set; }

        [FindsBy(How = How.Id, Using = "Childrens")]
        private IWebElement ChildrenDropdown { get; set; }

        [FindsBy(How = How.Id, Using = "Infants")]
        private IWebElement InfantsDropdown { get; set; }

        [FindsBy(How = How.Id, Using = "SearchBtn")]
        private IWebElement SearchBtn { get; set; }

        //SearchBtn

        public SearchResultsPage EnterSearchDetails(string from, string to, string date, string numberOfAdults, string numberOfChildren)
        {
            FromTxtBox.Clear();
            FromTxtBox.SendKeys(from);
            ToTxtBox.Clear();
            ToTxtBox.SendKeys(to);
            DepartureDateTxtBox.Clear();
            DepartureDateTxtBox.SendKeys(date);
            Utilities.SelectFromDropdown(AdultsDropdown, numberOfAdults);
            Utilities.SelectFromDropdown(ChildrenDropdown, numberOfChildren);
            SearchBtn.Click();
            SearchResultsPage sRP = new SearchResultsPage(_driver);
            PageFactory.InitElements(Driver.CurrentDriver, sRP);
            return sRP;
        }
    }
}
