﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System.Configuration;
using OpenQA.Selenium.Support.UI;
using JohnAkeTest.Support.HelperObjects;

namespace JohnAkeTest.Pages
{
    public class SearchResultsPage
    {
        private static IWebDriver _driver;
        public SearchResultsPage(IWebDriver driver)
        {
            _driver = driver;
        }

        [FindsBy(How = How.ClassName, Using = "flights")]
        private List<IWebElement> AllFlights { get; set; }

        public String GetCheapestFlight()
        {
            return AllFlights[0].Text;
        }

        public String GetMostExpensiveFlight()
        {
            return AllFlights[AllFlights.Count - 1].Text;
        }
    }
}
