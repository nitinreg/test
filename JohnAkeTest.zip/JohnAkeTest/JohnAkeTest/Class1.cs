﻿using System;

namespace JohnAkeTest
{
    public class Class1
    {
    }
}
