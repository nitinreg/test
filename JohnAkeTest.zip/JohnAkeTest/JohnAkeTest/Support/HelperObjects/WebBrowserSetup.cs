﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;

namespace JohnAkeTest.Support.HelperObjects
{
    class WebBrowserSetup
    {
        private static string _abrowser;
        public WebBrowserSetup()
        {
            _abrowser = ConfigurationManager.AppSettings["Browser"];
        }

        public void StartBrowser()
        {
            switch(_abrowser)
            {
                case "Chrome":
                    Driver.CurrentDriver = new ChromeDriver();
                    break;

                case "Firefox":
                    Driver.CurrentDriver = new FirefoxDriver();
                    break;

                default:
                    Console.WriteLine("Unsuported browser");
                    break;
            }

                
        }
    }
}
