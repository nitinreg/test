﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;

namespace JohnAkeTest.Support.HelperObjects
{
    public class Driver
    {
        public static IWebDriver CurrentDriver { get; set; }
    }
}
