﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace JohnAkeTest.Support.HelperObjects
{
    public class Utilities
    {
        public static void SelectFromDropdown(IWebElement element, string value)
        {
            SelectElement se = new SelectElement(element);
            se.SelectByValue(value);

        }
    }
}
