﻿using System;
using System.Collections.Generic;
//using spe

namespace JohnAkeTest.Steps
{
    //Binding]
    class HomepageSteps
    {
    }
}
