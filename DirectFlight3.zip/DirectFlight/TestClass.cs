﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

using AutomationCore.Enums;
using AutomationCore.Pages;
using NUnit.Framework;
using AutomationCore.Utilities;


namespace DirectFlight
{
    [TestFixture]
    public class TestClass
    {
        HomePage homePage;
        ResultsPage resultsPage;

        [SetUp]
        public void Setup()
        {
            homePage = new HomePage(Browsers.Chrome);
            resultsPage = new ResultsPage(Browsers.Chrome);
        }

        [Test]
        public void FlightSearch()
        { 
            homePage.Load();
            homePage.SearchFlights("London Heathrow","New Delhi",DateTime.Today, DateTime.Today);
        }

        [Test]
        public void CheapestFlight()
        {
            FlightSearch();
            var cheapestdetails = resultsPage.CheapestPriceFlightDetails();
            var price = cheapestdetails[1];
            Debug.WriteLine(price);
          //  resultsPage.PrintOnPage(price);

            new Utilities().WriteToExcel(price);
        }

        [Test]
        public void MinimumPrice()
        {
            FlightSearch();
            var flightdetails = resultsPage.GetMinimumPriceFlightDetails();
            Debug.WriteLine(flightdetails[flightdetails.Length - 3]);
            
            
        }

        [Test]
        public void BookFlight()
        {
            FlightSearch();
            resultsPage.BookCheapestFlight();
        }
            
        [TearDown]
        public void TearDown()
        {
            homePage.Close(); //same browser driver shared among pages, so can do close and quit from anypage
            homePage.Quit();
        }

      }
}
 