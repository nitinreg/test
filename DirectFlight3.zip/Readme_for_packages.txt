readme

testexplorer 
Tools -> Extensions and Updates -> Online" and search for "NUnit3 Test Adapter"

Nuget 
	Selenium.WebDriver
	Selenium.Support 		(IWebDriverwait etc)
	WebDriver.GeckoDriver
	NUnit.Framework
	chrome driver
	ie driver

Excel - COM - Search excel and select appropriateone
	    - MS excel 12.0 object library

Just add the drivers from package folder - solution -add ecisting 
and then set the property to copy to bin

