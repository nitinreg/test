﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Reflection;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using AutomationCore.Enums;

namespace AutomationCore
{
    public static class Driver
    {
        static IWebDriver ffWebDriver, chWebDriver, ieWebDriver ;
        
        /// <summary>
        /// GetDriver returns the driver based on the browser. Ensures max one driver instance each for each browser
        /// </summary>
        /// <param name="browser"></param>
        /// <returns></returns>
        internal static IWebDriver GetDriver(Browsers browser)
        {
            IWebDriver driver;
            switch (browser)
            {
                case Browsers.Firefox:
                    if (ffWebDriver == null)                    
                            ffWebDriver = new FirefoxDriver();

                    driver = ffWebDriver;                  
                    break;

                case Browsers.Chrome:
                    if(chWebDriver == null)
                            chWebDriver =  new ChromeDriver(GetDriverPath());

                    driver = chWebDriver;
                    break;

                case Browsers.IE:
                    if(ieWebDriver == null)
                            ieWebDriver = new InternetExplorerDriver(GetDriverPath());

                    driver = chWebDriver;
                    break;

                default: throw new Exception("Invalid Driver");
            }

            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            driver.Manage().Window.Maximize();
            return driver;           
         }

        private static string GetDriverPath()
        {
            //System.setProperty("webdriver.chrome.driver", "/path/to/chromedriver");
            //WebDriver driver = new ChromeDriver();

            var outPutDirectory = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            //var relativePath = @"..\..\..\Framework\Drivers";
            //return Path.GetFullPath(Path.Combine(outPutDirectory, relativePath));
            return outPutDirectory;
        }

        public static void Goto(IWebDriver driver,string url)
        {
            if (!string.IsNullOrEmpty(url))
                driver.Url = url;
            else
                throw new Exception("Null or empty url");
        }

        public static void Close(IWebDriver driver) 
        {
            driver.Close();
        }

        public static void Quit(IWebDriver driver) 
        {
            driver.Quit();
        }        
    }
}
