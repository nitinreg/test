﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Chrome;
//using OpenQA.Selenium.Support.UI;

using NUnit.Framework;

namespace AutomationCore
{
    [TestFixture]
    public class AutomationBase
    {
        [Test]
        public void StartAutomation() //to be changed - entire working here at this moment
        {
            IWebDriver driver = new FirefoxDriver(); //working due to geckodriver
            driver.Url = "https://directflights.com";
            //An exception of type 'OpenQA.Selenium.DriverServiceNotFoundException' occurred in WebDriver.dll but was not handled in user code
            //Additional information: The geckodriver.exe file does not exist in the current directory or in a directory on the PATH environment variable.The driver can be downloaded at https://github.com/mozilla/geckodriver/releases.

            //IWebDriver driver = new InternetExplorerDriver();
            //driver.Url = "https://directflights.com";
            //An exception of type 'OpenQA.Selenium.DriverServiceNotFoundException' occurred in WebDriver.dll but was not handled in user code
            //Additional information: The IEDriverServer.exe file does not exist in the current directory or in a directory on the PATH environment variable.The driver can be downloaded at http://selenium-release.storage.googleapis.com/index.html.

            // IWebDriver driver = new ChromeDriver();
            // driver.Url = "https://directflights.com";

            //todo - chromedriver.exe 
            //The chromedriver.exe file does not exist in the current directory or in a directory on the PATH environment variable.The driver can be downloaded at http://chromedriver.storage.googleapis.com/index.html.

            //search for flights
            IWebElement elementFlightFrom = driver.FindElement(By.Id("txtFrom"));
            elementFlightFrom.Clear();
            elementFlightFrom.SendKeys("London Heathrow"); //todo put this in some app.config file
                                                                                 //also how to select from drop down

            IWebElement airportFromUL = driver.FindElement(By.Id("ui-id-1"));
            //List<IWebElement> airportList
            var airportFromList = airportFromUL.FindElements(By.TagName("li"));
            foreach (IWebElement li in airportFromList)
            {
                if (li.Text.Contains("London Heathrow"))
                {
                    li.Click();
                }
            }

            //IWebElement elementFlightTo = driver.FindElement(By.Id("txtFrom"));
            IWebElement elementFlightTo = driver.FindElement(By.Id("txtTo"));
            elementFlightTo.Clear();
            elementFlightTo.SendKeys("New Delhi");
            System.Threading.Thread.Sleep(3);
            IWebElement airportToUL = driver.FindElement(By.Id("ui-id-3"));
            var airportToList = airportToUL.FindElements(By.TagName("li"));
            foreach (IWebElement li in airportToList)
            {
                if (li.Text.Contains("New Delhi"))
                {
                    li.Click();
                }
            }

            //select calendar dates
            
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            js.ExecuteScript("document.getElementById('flights_calendar_depart_inp_org').value='2018-10-10'");
            driver.FindElement(By.CssSelector("i[class= 'icon calendar_depart']")).Click();

            js.ExecuteScript("document.getElementById('flights_calendar_return_inp_org').value='2018-10-12'");
            driver.FindElement(By.CssSelector("i[class='icon calendar_return']")).Click();

            elementFlightTo.Submit();

            driver.Close();
            driver.Quit();


        }
    }
}
