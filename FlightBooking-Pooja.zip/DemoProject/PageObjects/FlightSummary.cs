﻿using OpenQA.Selenium;

namespace DemoProject.PageObjects
{
    public class FlightSummary : PageBase
    {
        #region WebElement
        public IWebElement ContinueBookingButton => driver.FindElement(By.Id("itineraryBtn"));

        public IWebElement EmailInput => driver.FindElement(By.Id("username"));
        public IWebElement SubmitEmailButton => driver.FindElement(By.Id("LoginContinueBtn_1"));
        // Adult traveller elements
        public IWebElement AdultTitle => driver.FindElement(By.Id("AdultTitle1"));
        public IWebElement AdultFirstName(int index) => driver.FindElement(By.Id($"AdultFname{index}"));
        public IWebElement AdultLastName(int index) => driver.FindElement(By.Id($"AdultLname{index}"));
        public IWebElement AdultDobDay(int index) => driver.FindElement(By.Id($"AdultDobDay{index}"));
        public IWebElement AdultDobDayValue(int index, string value) => driver.FindElement(By.XPath($"//*[@id='AdultDobDay{index}']/option[@value='{value}']"));
        public IWebElement AdultDobMonth(int index) => driver.FindElement(By.Id($"AdultDobMonth{index}"));
        public IWebElement AdultDobMonthValue(int index, string value) => driver.FindElement(By.XPath($"//*[@id='AdultDobMonth{index}']/option[text()='{value}']"));
        public IWebElement AdultDobYear(int index) => driver.FindElement(By.Id($"AdultDobYear{index}"));
        public IWebElement AdultDobYearValue(int index, string value) => driver.FindElement(By.XPath($"//*[@id='AdultDobYear{index}']/option[@value='{value}']"));
        //Child traveller elements
        public IWebElement ChildTitle => driver.FindElement(By.Id("ChildTitle1"));
        public IWebElement ChildFirstName(int index) => driver.FindElement(By.Id($"ChildFname{index}"));
        public IWebElement ChildLastName(int index) => driver.FindElement(By.Id($"ChildLname{index}"));
        public IWebElement ChildDobDay(int index) => driver.FindElement(By.Id($"ChildDobDay{index}"));
        public IWebElement ChildDobDayValue(int index, string value) => driver.FindElement(By.XPath($"//*[@id='ChildDobDay{index}']/option[@value='{value}']"));
        public IWebElement ChildDobMonth(int index) => driver.FindElement(By.Id($"ChildDobMonth{index}"));
        public IWebElement ChildDobMonthValue(int index, string value) => driver.FindElement(By.XPath($"//*[@id='ChildDobMonth{index}']/option[text()='{value}']"));
        public IWebElement ChildDobYear(int index) => driver.FindElement(By.Id($"ChildDobYear{index}"));
        public IWebElement ChildDobYearValue(int index, string value) => driver.FindElement(By.XPath($"//*[@id='ChildDobYear{index}']/option[@value='{value}']"));
        public IWebElement MobileNumberInput => driver.FindElement(By.Id("mobileNumber"));
        public IWebElement TravellerButton => driver.FindElement(By.Id("travellerBtn"));

        public FlightSummary(IWebDriver driver) : base(driver)
        {
            this.driver = driver;
        }
        #endregion


        #region Action

        public string GetTitle() => DriverRepository.driver.Title;

        public void ContinueAndBookTicket()
        {
            WaitForElement(By.Id("itineraryBtn"));
            ContinueBookingButton.Click();
        }
        public void inputEmail()
        {
            EmailInput.SendKeys("a@b.com");
            SubmitEmailButton.Click();
        }

        public void SubmitTravellerDetails()
        {
            AdultTitle.SendKeys("Mrs");
            AdultTitle.SendKeys(Keys.Enter);
            AdultFirstName(1).SendKeys("Jack");
            AdultLastName(1).SendKeys("Smith");
            AdultDobDay(1).Click();
            AdultDobDayValue(1, "2").Click();
            AdultDobMonth(1).Click();
            AdultDobMonthValue(1, "Nov").Click();
            AdultDobYear(1).Click();
            AdultDobYearValue(1, "1983").Click();

            ChildTitle.SendKeys("Miss");
            ChildTitle.SendKeys(Keys.Enter);
            ChildFirstName(1).SendKeys("Jane");
            ChildLastName(1).SendKeys("Smith");
            ChildDobDay(1).Click();
            ChildDobDayValue(1, "10").Click();
            ChildDobMonth(1).Click();
            ChildDobMonthValue(1, "Jan").Click();
            ChildDobYear(1).Click();
            ChildDobYearValue(1, "2014").Click();
            MobileNumberInput.SendKeys("9999988888");
            TravellerButton.Click();
        }
        #endregion
    }
}
