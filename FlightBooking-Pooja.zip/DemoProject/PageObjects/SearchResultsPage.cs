﻿using OpenQA.Selenium;
using System;
using System.Diagnostics;
using System.Threading.Tasks;

namespace DemoProject.PageObjects
{
    public class SearchResultsPage : PageBase
    {
        private string firstPriceItem = "//*[@id='flightForm']//li[1]//*[@class='bundlePrice']";
        #region WebElement
        public IWebElement firstPriceElement => driver.FindElement(By.XPath(firstPriceItem));
        public IWebElement PriceSortButton => driver.FindElement(By.CssSelector("li.price > a"));
        public IWebElement PriceOfLeastExpensive => driver.FindElement(By.CssSelector("#withCabinBaggage > span.bundlePrice"));
        public IWebElement BookButton => driver.FindElement(By.CssSelector("#flightForm > section.resultsContainer > div.row.legsContainer > div > nav > ul > li.listItem.showTabs.bundled.bundlePriceActive > table > tbody:nth-child(2) > tr:nth-child(1) > td > button"));
        public IWebElement SearchSummary => driver.FindElement(By.CssSelector("#GlobalNav > div > div.ctCol.ctCenter > div > strong"));
        #endregion

        #region Action

        public SearchResultsPage(IWebDriver driver) : base(driver)
        {
            this.driver = driver;
        }

        public string GetTitle() => DriverRepository.driver.Title;

        public String SearchSummaryDetails()
        {
            return SearchSummary.Text;
        }

        public void GetPriceOfLeastExpensive()
        {
            WaitForElement(By.XPath(firstPriceItem));          
            Console.WriteLine(firstPriceElement.Text);
            Trace.WriteLine(firstPriceElement.Text);
        }

        public void SortThePriceToMostExpensive()
        {
            WaitForElement(By.CssSelector("#sorterTpl > ul > li.price > a"));
            PriceSortButton.Click();
        }

        public FlightSummary BookaTicket()
        {
            WaitForElement(By.CssSelector("#sorterTpl > ul > li.price > a"));
            BookButton.Click();
            return new FlightSummary(driver);
        }

        #endregion
    }
}
