﻿using OpenQA.Selenium;
using System;

namespace DemoProject.PageObjects
{
    public class HomePage : PageBase
    {
        #region WebElement
        // Using IWebElement as PageFactory is Deprecated 
        public IWebElement PageName => driver.FindElement(By.CssSelector("#SearchForm > h1"));
        public IWebElement TripType => driver.FindElement(By.Id("RoundTrip"));
        public IWebElement FromDestination => driver.FindElement(By.Id("FromTag"));
        public IWebElement ToDestination => driver.FindElement(By.Id("ToTag"));
        public IWebElement StartDate => driver.FindElement(By.Id("DepartDate"));
        public IWebElement SelectStartDate(String StartDateInt) => driver.FindElement(By.XPath($"//*[@id='ui-datepicker-div']/div[2]/table/tbody//a[text()='{StartDateInt}']"));
        public IWebElement EndDate => driver.FindElement(By.Id("ReturnDate"));
        public IWebElement SelectEndDate(String EndDateInt) => driver.FindElement(By.XPath($"//*[@id='ui-datepicker-div']/div[2]/table/tbody//a[text()='{EndDateInt}']"));
        public IWebElement SearchButton => driver.FindElement(By.Id("SearchBtn"));
        public IWebElement Adults => driver.FindElement(By.Id("Adults"));
        public IWebElement Children => driver.FindElement(By.Id("Childrens"));
        public IWebElement DepartHintMessage => driver.FindElement(By.XPath("//*[@id='ORtrip']//small"));
        public IWebElement NoSearchResults => driver.FindElement(By.CssSelector("#ResultContainer_1_1 > div.messageScreen > div > a"));

        public HomePage(IWebDriver driver) : base(driver)
        {
            this.driver = driver;
        }

        #endregion

        #region Action

        public void NavigateToURL(String url)
        {
            DriverRepository.driver.Navigate().GoToUrl(url);
        }

        public string GetPageName() => PageName.Text;
        public string GetTitle() => DriverRepository.driver.Title;
        public void SelectTripType() => TripType.Click();

        public void SelectFromTo(String Origin, String Destination)
        {
            WaitForElementToBeClickable(By.Id("FromTag"));
            FromDestination.SendKeys(Origin);
            FromDestination.SendKeys(Keys.ArrowDown);
            FromDestination.SendKeys(Keys.Enter);

            WaitForElementToBeClickable(By.Id("ToTag"));
            ToDestination.SendKeys(Destination);
            ToDestination.SendKeys(Keys.ArrowDown);
            ToDestination.SendKeys(Keys.Enter);
        }


        public void SelectedStartDate(string startDateIndex)
        {
            StartDate.Click();
            SelectStartDate(startDateIndex).Click();
        }

        public void SelectedEndDateOfTravel(string endDateIndex)
        {
            EndDate.Click();
            SelectEndDate(endDateIndex).Click();
        }

        public void SelectAdults(int NumberOfAdults)
        {
            Adults.SendKeys(NumberOfAdults.ToString());
            Adults.SendKeys(Keys.Enter);
        }

        public void SelectChildren(int NumberofChildren)
        {
            WaitForElementToBeClickable(By.Id("Childrens"));
            Children.SendKeys(NumberofChildren.ToString());
            Children.SendKeys(Keys.Enter);
        }

        public SearchResultsPage Search()
        {
            WaitForElementToBeClickable(By.Id("SearchBtn"));
            SearchButton.Click();
            return new SearchResultsPage(driver);
        }

        public void NoResultsPage()
        {
            NoSearchResults.Click();
            WaitForElementToBeClickable(By.Id("SearchBtn"));
            SearchButton.Click();
        }
        #endregion
    }
}
