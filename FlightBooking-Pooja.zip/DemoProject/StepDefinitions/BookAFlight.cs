﻿using DemoProject.PageObjects;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Configuration;
using TechTalk.SpecFlow;

namespace DemoProject.StepDefinitions
{
    [Binding]

    public class StepDefinitions : Steps
    {
        HomePage homePage = new HomePage(DriverRepository.driver);
        SearchResultsPage searchResultsPage = new SearchResultsPage(DriverRepository.driver);
        FlightSummary flightSummary = new FlightSummary(DriverRepository.driver);

        [When(@"I click on Search button")]
        public void WhenIClickOnSearchButton()
        {
            homePage.Search();

        }

        [Then(@"I should be navigated to the search results")]
        public void ThenIShouldBeNavigatedToTheSearchResults()
        {
            Assert.AreEqual("London ⇄ Munich", searchResultsPage.SearchSummaryDetails());
        }


        [Given(@"I am on the Cleartrip website")]
        public void GivenIAmOnTheCleartripWebsite()
        {
            string url = ConfigurationManager.AppSettings["baseurl"];
            homePage.NavigateToURL(url);
            homePage.SelectTripType();
        }

        [Given(@"I am on the Search Flight Page")]
        public void GivenIAmOnTheSearchFlightPage()
        {
            // Assert.AreEqual("Search flights", "");
        }

        [Given(@"I enter the StartDestination and EndDestination")]
        public void WhenIEnterTheStartDestinationAndEndDestination()
        {
            ScenarioContext.Current.Add("Origin", "LON");
            ScenarioContext.Current.Add("Destination", "Munich");
            homePage.SelectFromTo((string)ScenarioContext.Current["Origin"], (string)ScenarioContext.Current["Destination"]);
        }

        [Given(@"I enter the StartDate as (.*)")]
        public void WhenIEnterTheStartDateAs(string StartDateIndex)
        {
            homePage.SelectedStartDate(StartDateIndex);
        }

        [Given(@"I enter the EndDate as (.*)")]
        public void WhenIEnterTheEndDateAs(string EndDateIndex)
        {
            homePage.SelectedEndDateOfTravel(EndDateIndex);
        }

        [Given(@"I enter Adults as (.*)")]
        public void WhenIEnterAdultsAs(int NumberOfAdults)
        {
            homePage.SelectAdults(NumberOfAdults);
        }

        [Given(@"I enter Children as (.*)")]
        public void WhenIEnterChildrenAs(int NumberofChildren)
        {
            homePage.SelectChildren(NumberofChildren);
        }

        [Then(@"I am on Search results page")]
        public void GivenIAmOnSearchResultsPage()
        {
          //  Assert.AreEqual("#1 Site for Booking Flights, Hotels Online in United Arab Emirates - Cleartrip", searchResultsPage.GetTitle());
        }

        [Then(@"the least expensive price is printed")]
        public void GivenTheLeastExpensivePriceIsPrinted()
        {
            searchResultsPage.GetPriceOfLeastExpensive();
        }

        [Then(@"I click on Price filter button")]
        public void WhenIClickOnPriceFilterButton()
        {
            searchResultsPage.SortThePriceToMostExpensive();
        }


        [Then(@"I click on the Book Button")]
        public void WhenIClickOnTheBookButton()
        {
            searchResultsPage.BookaTicket();
        }

        [Then(@"I should be navigated to the Booking confirmtation page")]
        public void ThenIShouldBeNavigatedToTheBookingConfirmtationPage()
        {
        }


        [Then(@"I click on Continue button")]
        public void WhenIClickOnContinueButton()
        {
            flightSummary.ContinueAndBookTicket();
        }

        [Then(@"I submit my email address")]
        public void GivenISubmitMyEmailAddress()
        {
            flightSummary.inputEmail();
        }

        [Then(@"I submit traveller details")]
        public void GivenISubmitTravellerDetails()
        {
            flightSummary.SubmitTravellerDetails();
        }
    }
}
