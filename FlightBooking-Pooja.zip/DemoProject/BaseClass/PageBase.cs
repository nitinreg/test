﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;

namespace DemoProject
{
    public class PageBase
    {
        public IWebDriver driver;

        public PageBase() { }
        public PageBase(IWebDriver driver) => this.driver = driver;

        public void WaitForElementToBeClickable(By by)
        {
           // timeout must be used as a parameter
            TimeSpan timeout = TimeSpan.FromMilliseconds(60000);
                WebDriverWait wait = new WebDriverWait(DriverRepository.driver,timeout);
            wait.Until(ExpectedConditions.ElementToBeClickable(by));
        }

        public void WaitForElement(By by)
        {
            var wait = new WebDriverWait(DriverRepository.driver, TimeSpan.FromSeconds(30));
            wait.Until(ExpectedConditions.ElementIsVisible(by));
        }

    }

}
