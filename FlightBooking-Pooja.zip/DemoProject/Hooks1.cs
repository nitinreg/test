﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using TechTalk.SpecFlow;

namespace DemoProject
{
    [Binding]
  
    public sealed class Hooks1
    {
        [BeforeScenario]
        public void BeforeScenario()
        {
            ChromeOptions options = new ChromeOptions();
            options.AddArguments("--start-maximized");
            options.AddArguments("--disable-geolocation");
            IWebDriver driver = new ChromeDriver(options);
            DriverRepository.driver = driver;
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromMilliseconds(10000);
        }

        [AfterScenario]
        public void AfterScenario()
        {
         DriverRepository.driver.Close();
         DriverRepository.driver.Quit();
        }
    }
}
