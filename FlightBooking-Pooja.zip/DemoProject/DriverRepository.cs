﻿using OpenQA.Selenium;

namespace DemoProject
{
    public class DriverRepository
    {
        public static IWebDriver driver;
    }
}
