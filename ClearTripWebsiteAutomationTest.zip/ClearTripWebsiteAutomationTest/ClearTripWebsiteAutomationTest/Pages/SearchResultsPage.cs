﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;

using System.Threading;
using NUnit.Framework;

namespace ClearTripWebsiteAutomationTest.Pages
{
    class SearchResultsPage
    {
        IWebDriver webDriver;
        WebDriverWait wait;

        string cheapAirlinePriceText;
        string reviewYourFlightDetailsTextValue = "Review your flight details";

        public SearchResultsPage(IWebDriver webDriver)
        {
            this.webDriver = webDriver;
            wait = new WebDriverWait(webDriver, TimeSpan.FromSeconds(15));
        }

        #region Objects

        private IWebElement CheapestPriceValue
        {
            get
            {
                return webDriver.FindElement(By.XPath("//*[@id='withCabinBaggage']/span[1]"));
            }
        }

        private IWebElement PriceSortOption
        {
            get
            {
                return webDriver.FindElement(By.XPath("//*[@id='sorterTpl']/ul/li[9]/a"));
            }
        }

        private IWebElement BookButton
        {
            get
            {
                return webDriver.FindElement(By.XPath("//*[@id='flightForm']/section[2]/div[4]/div/nav/ul/li[1]/table/tbody/tr[1]/td/button"));
            }
        }


        //
        private IWebElement ReviewYourFlightDetailsText
        {
            get
            {
                return webDriver.FindElement(By.XPath("//*[@id='itineraryOpen']/div[1]/p"));
            }
        }

        //itineraryBtn

        private IWebElement ContinueButtton
        {
            get
            {
                return webDriver.FindElement(By.Id("itineraryBtn"));
            }
        }

        #endregion

        #region Methods

        public void GetCheapAirlinePrice()
        {
            try
            {
                cheapAirlinePriceText = CheapestPriceValue.Text;
                Console.WriteLine("Cheapest airline price is: " + cheapAirlinePriceText);
            }
            catch(Exception e)
            {
                Console.WriteLine("Exception occurred in 'GetCheapAirlinePrice'" + e.StackTrace);
            }
        }

        public void ClickOnPriceSortOption()
        {
            try
            {
                PriceSortOption.Click();
                Thread.Sleep(5);
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception occurred in 'ClickOnPriceSortOption'" + e.StackTrace);
            }
        }

        public void ClickOnBookButton()
        {
            try
            {
                BookButton.Click();
                Thread.Sleep(5);
            }

            catch (Exception e)
            {
                Console.WriteLine("Exception occurred in 'ClickOnBookButton'" + e.StackTrace);
            }
        }

        public void VerifyNavigationToReviewYourFlightDetailsPage()
        {
            Assert.AreEqual(reviewYourFlightDetailsTextValue, ReviewYourFlightDetailsText.Text);
        }

        public void ClickOnContinueButton()
        {
            ContinueButtton.Click();
        }

        #endregion
    }
}
