﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;

using System.Threading;

namespace ClearTripWebsiteAutomationTest.Pages
{
    class HomePage
    {
        IWebDriver webDriver;
        string fromAirportValue = "London,GB - All airports (LON)";
        string toAirportValue = "Munich,DE - Munich (MUC)";
        string departureDateValue = "22/06/2018";
        string adultsSelectOptionValue = "1";
        string childrenSelectOptionValue = "1";

        public HomePage(IWebDriver webDriver)
        {
            this.webDriver = webDriver;
        }


        #region Objects

        private IWebElement AirportFromTextBox
        {
            get
            {
                //FromTag - id
                return webDriver.FindElement(By.Id("FromTag"));
            }
        }

        private IWebElement AirportToTextBox
        {
            get
            {
                //ToTag - id
                return webDriver.FindElement(By.Id("ToTag"));
            }
        }

        private IWebElement DepartureDateTextBox
        {
            get
            {
                //DepartDate - id
                return webDriver.FindElement(By.Id("DepartDate"));
            }
        }

        private IWebElement AdultsDropDownList
        {
            get
            {
                //Adults - id
                return webDriver.FindElement(By.Id("Adults"));
            }
        }

        private IWebElement ChildrensDropDownList   
        {
            get
            {
                //Childrens - id
                return webDriver.FindElement(By.Id("Childrens"));
            }
        }

        private IWebElement SearchFlightButton
        {
            get
            {
                return webDriver.FindElement(By.Id("SearchBtn"));
            }
        }
        #endregion

        #region Methods

        public void EnterAirportFrom(string fromAirport)
        {
            try
            {
                AirportFromTextBox.Clear();
                AirportFromTextBox.SendKeys(fromAirport);
            }
            catch(Exception e)
            {
                Console.WriteLine("Exception occurred in 'EnterAirportFrom'"  + e.StackTrace);
            }
        }

        public void EnterAirportTo(string toAirport)
        {
            try
            {
                AirportToTextBox.Clear();
                AirportToTextBox.SendKeys(toAirport);
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception occurred in 'EnterAirportTo'" + e.StackTrace);
            }
        }

        public void EnterDepartureDate(string departureDate)
        {
            try
            {
                DepartureDateTextBox.Clear();
                DepartureDateTextBox.SendKeys(departureDate);
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception occurred in 'EnterDepartureDate'" + e.StackTrace);
            }
        }

        public void SelectAdultsOption(string optionValue)
        {
            try
            {
                var selectElement = new SelectElement(AdultsDropDownList);
                selectElement.SelectByText(optionValue);
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception occurred in 'SelectAdultsOption'" + e.StackTrace);
            }
        }

        public void SelectChildrenOption(string optionValue)
        {
            try
            {
                var selectElement = new SelectElement(ChildrensDropDownList);
                selectElement.SelectByText(optionValue);
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception occurred in 'SelectChildrenOption'" + e.StackTrace);
            }
        }

        public SearchResultsPage ClickOnSearchFlights()
        {
            
                SearchFlightButton.Click();
                Thread.Sleep(10);
                return new SearchResultsPage(webDriver);
            
        }

        public void EnterFlightDetailsAndClickOnSearchFlight()
        {
            try
            {
                EnterAirportFrom(fromAirportValue);
                EnterAirportTo(toAirportValue);
                EnterDepartureDate(departureDateValue);
                SelectAdultsOption(adultsSelectOptionValue);
                SelectChildrenOption(childrenSelectOptionValue);
                ClickOnSearchFlights();
                Thread.Sleep(10);
                //webDriver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(10);
            }
            catch(Exception e)
            {
                Console.WriteLine("Exception occurred in 'EnterFlightDetailsAndClickOnSearchFlight'" + e.StackTrace);
            }
        }

        #endregion
    }
}
