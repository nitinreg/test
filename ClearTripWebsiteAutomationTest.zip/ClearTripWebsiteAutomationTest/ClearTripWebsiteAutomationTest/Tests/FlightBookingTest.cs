﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using System.Configuration;
using System.Threading;

using NUnit.Framework;
using ClearTripWebsiteAutomationTest.Pages;

namespace ClearTripWebsiteAutomationTest.Tests
{
    class FlightBookingTest
    {
        IWebDriver webDriver;

        HomePage homePage;
        SearchResultsPage searchResultsPage;

        string webSiteURL;

        [SetUp]
        public void InitializeBrowser()
        {
            webDriver = new ChromeDriver(@"C:\BrowserDrivers");
            //webDriver = new FirefoxDriver(@"C:\BrowserDrivers");
            webDriver.Manage().Window.Maximize();

            webSiteURL = ConfigurationManager.AppSettings["ClearTripWebSiteURL"];

            webDriver.Navigate().GoToUrl(webSiteURL);
            webDriver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(10);
        }

        [Test]
        public void FlightSearchAndBookingTest()
        {
            homePage = new HomePage(webDriver);
            searchResultsPage = new SearchResultsPage(webDriver);

            homePage.EnterFlightDetailsAndClickOnSearchFlight();

            Thread.Sleep(5000);
            searchResultsPage.GetCheapAirlinePrice();

            //This sort option displays highest/expensive price
            searchResultsPage.ClickOnPriceSortOption(); 

            searchResultsPage.ClickOnBookButton();

            searchResultsPage.VerifyNavigationToReviewYourFlightDetailsPage();

            searchResultsPage.ClickOnContinueButton();

            // Write data to text file
            WriteDataToFile textFile = new WriteDataToFile();
            textFile.WriteSiteDataToTextFile("London,GB - All airports (LON)", "Munich,DE - Munich (MUC)");
        }

        [TearDown]
        public void CloseBrowser()
        {
           // webDriver.Close();
        }

    }
}
