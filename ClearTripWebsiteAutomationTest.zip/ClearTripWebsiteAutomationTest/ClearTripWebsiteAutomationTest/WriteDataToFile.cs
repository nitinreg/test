﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ClearTripWebsiteAutomationTest
{
    class WriteDataToFile
    {
        public void WriteSiteDataToTextFile(string flightFrom,string flightTo)
        {
           
            FileStream fileStream = File.Open(@"C:\BrowserDrivers\FlightBookingData.txt", FileMode.Append, FileAccess.Write);
            
            StreamWriter fileWriter = new StreamWriter(fileStream);

            // Write the flight details to the file
            fileWriter.WriteLine("Flight From : " + flightFrom);
            fileWriter.WriteLine("Flight To : " + flightTo);
            fileWriter.Flush();
            fileWriter.Close();
        }

    }
}
