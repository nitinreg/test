﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.IO;
using System.Reflection;
using AutomationCore.Enums;

namespace AutomationCore
{
  public class Driver
    {
        public IWebDriver GetDriver(Browsers browser)
        {
            //IWebDriver webDriver;

            switch (browser)
           {
               case Browsers.Chrome:
                    return new ChromeDriver(GetDriverPath());
                    //webDriver = new ChromeDriver(GetDriverPath());
                    // break;
           
               case Browsers.Firefox:
                        //not implemented as not needed as per this test
                        throw new Exception("not implemented");
                                                    
               case Browsers.IE:
                        //not implemented as not needed as per this test
                        throw new Exception("not implemented");

                default:
                        throw new Exception("Invalid Driver");

            }
            
            //return webDriver;
        }

        private static string GetDriverPath()
        {
            //System.setProperty("webdriver.chrome.driver", "/path/to/chromedriver");
            //WebDriver driver = new ChromeDriver();

            var outPutDirectory = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            //var relativePath = @"..\..\..\Framework\Drivers";
            //return Path.GetFullPath(Path.Combine(outPutDirectory, relativePath));
            return outPutDirectory;
        }
    }
}
