﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using AutomationCore.Enums;
using System.Configuration;

namespace AutomationCore.PageObjects
{
    public class HomePage : PageBase
    {
        private IWebElement Origin => driver.FindElement(By.Id("FromTag"));
        private IWebElement Destination => driver.FindElement(By.Id("ToTag"));
        private IWebElement CalIcon => driver.FindElement(By.CssSelector("i[class= 'icon ir datePicker']"));
        private IWebElement DepartDate => driver.FindElement(By.Id("DepartDate"));
        private IWebElement OneWay => driver.FindElement(By.Id("OneWay"));
        private IWebElement Adults => driver.FindElement(By.Id("Adults"));
        private IWebElement Children => driver.FindElement(By.Id("Childrens"));
        private IWebElement SearchBtn => driver.FindElement(By.Id("SearchBtn"));


        public HomePage(Browsers browser) : base(browser) { }

        public void Load()
        {
            var baseUrl = ConfigurationManager.AppSettings["baseUrl"].ToString();
            Goto(baseUrl);
        }

        public void SelectOrigin(string origin)
        {
            Origin.SendKeys(origin);
            var suggestedOrigins = driver.FindElements(By.XPath("//ul[@id='ui-id-1']/li"));
            //this element is available to be used when from/origin is keyed in

            foreach (IWebElement suggestion in suggestedOrigins)
            {
                if (!suggestion.Text.Contains(origin))
                    continue;
                
                suggestion.Click();
                break;                
            }            
        }

        public void SelectDestination(string destination)
        {
            Destination.SendKeys(destination);
            var suggestedDestinations = driver.FindElements(By.XPath("//ul[@id='ui-id-2']/li"));
            //this element is available to be used when to/destination is keyed in

            foreach (IWebElement suggestion in suggestedDestinations)
            {
                if (!suggestion.Text.Contains(destination))
                    continue;

                suggestion.Click();
                break;
            }
        }

        public void SelectDepartureDate(string date)
        {
            var departdate = "DepartDate.value='" + date + "'";
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            js.ExecuteScript(departdate);            
        }

        public void SelectOneWayTrip()
        {
            OneWay.Click();
        }

        public void SelectNumberOfAdults(int noOfAdults)
        {
            var selectAdults = new SelectElement(Adults);
            //Adults.Click();
            selectAdults.SelectByText(noOfAdults.ToString());
            //Adults.Click();

            //IList<IWebElement> allOptions = Adults.FindElements(By.TagName("option"));
            //foreach (IWebElement option in allOptions)
            //{
            //    if (Convert.ToInt32(option.GetAttribute("value")) == noOfAdults)
            //    { 
            //        option.Click();
            //        break;
            //    }
            //}
        }

        public void SelectNumberOfChildren(int noOfChildren)
        {
            var selectChildren = new SelectElement(Children);
           // Children.Click();
            selectChildren.SelectByText(noOfChildren.ToString());
           // Children.Click();

            /*IList<IWebElement> allOptions = Children.FindElements(By.TagName("option"));
            foreach (IWebElement option in allOptions)
            {
                if (Convert.ToInt32(option.GetAttribute("value")) == noOfChildren)
                { 
                    option.Click();                                       
                    break;
                }
            }
            */
        }

        public void SearchFlights()
        {
            SearchBtn.Click();
        }
       
    }
}