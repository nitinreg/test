﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutomationCore.Enums;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;


namespace AutomationCore.PageObjects
{
    public class SearchResultsPage : PageBase
    {
        private IWebElement PriceSort => driver.FindElement(By.CssSelector("#sorterTpl>ul>li.price>a"));
        
        public SearchResultsPage(Browsers browser) : base(browser) {}

        public void WaitForResults()
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(30)); //timeout value could be specified in app.config file.            
            wait.Until(ExpectedConditions.ElementExists(By.CssSelector("button[class='booking']")));
        }

        public void SortPriceAsc()
        {
            if(!driver.PageSource.Contains("current sortAsc"))  //sort only if not already sorted in ascending order
            {
                PriceSort.Click();
            }
        }

        public void SortPriceDesc()
        {
            if (!driver.PageSource.Contains("current sortDesc"))  //sort only if not already sorted in descending order
            {
                PriceSort.Click();
            }
        }

        public decimal FirstPrice()
        {
            var flightPrices = GetAllPrices();
            var firstPrice = flightPrices[0].FindElement(By.CssSelector("span[class='AED currencyCode']"));
            return Convert.ToDecimal(firstPrice.GetAttribute("data-pr"));
        }
       
        public decimal CheapestPrice()
        {
            SortPriceAsc();
            var flightPrices = GetAllPrices();
            var minPrice = FirstPrice();// Convert.ToDecimal(flightPrices[0].Text);

            foreach (IWebElement priceDetail in flightPrices)
            {
                var priceData = priceDetail.FindElement(By.CssSelector("span[class='AED currencyCode']"));
                var price = Convert.ToDecimal(priceData.GetAttribute("data-pr"));

                if (price < minPrice)
                      minPrice = price;                                    
            }
            return minPrice;
        }
      

        public void BookMostExpensiveFlight()
        {
            SortPriceDesc();
            //Now select the first flight ticket as it will be the most expensive

            Wait(5000);
            var allPrices = driver.FindElements(By.CssSelector("button[class='booking']"));
            allPrices[0].Click();
        }


        public IList<IWebElement> GetAllPrices()
        {
            var allPrices = driver.FindElements(By.CssSelector("span[class='bundlePrice']"));
            //allPrices = driver.FindElements(By.CssSelector("span[attribute='data-pr']"));
            return allPrices;
        }
    }
}
