﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutomationCore.Enums;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace AutomationCore.PageObjects
{
    public class ReviewPage : PageBase
    {
        int timeout = 30;  //timeout value could be moved to app.config file.

        private IWebElement AdultTitle1 => driver.FindElement(By.Id("AdultTitle1"));
        private IWebElement AdultFname1 => driver.FindElement(By.Id("AdultFname1"));
        private IWebElement AdultLname1 => driver.FindElement(By.Id("AdultLname1"));
        private IWebElement AdultDobDay1 => driver.FindElement(By.Id("AdultDobDay1"));
        private IWebElement AdultDobMonth1 => driver.FindElement(By.Id("AdultDobMonth1"));
        private IWebElement AdultDobYear1 => driver.FindElement(By.Id("AdultDobYear1"));
        private IWebElement MobileNumber => driver.FindElement(By.Id("mobileNumber"));

        private IWebElement ChildTitle1 => driver.FindElement(By.Id("ChildTitle1"));
        private IWebElement ChildFname1 => driver.FindElement(By.Id("ChildFname1"));
        private IWebElement ChildLname1 => driver.FindElement(By.Id("ChildLname1"));
        private IWebElement ChildDobDay1 => driver.FindElement(By.Id("ChildDobDay1"));
        private IWebElement ChildDobMonth1 => driver.FindElement(By.Id("ChildDobMonth1"));
        private IWebElement ChildDobYear1 => driver.FindElement(By.Id("ChildDobYear1"));


        public ReviewPage(Browsers browser) : base(browser) { }

        public bool HasLoaded()
        {
            var hasLoaded = false;
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeout));

            try
            { 
                wait.Until(ExpectedConditions.ElementExists(By.CssSelector("p[class='fRight subHead']")));
                hasLoaded = true;
            }
            catch
            {
                hasLoaded = false;
            }

            return hasLoaded;
        }

        public void ContinueBooking()
        {
            driver.FindElement(By.Id("itineraryBtn")).Click();
        }

        public void EnterEmailAddress(string emailAddress)
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeout));
            wait.Until(ExpectedConditions.ElementExists(By.Id("username")));

            driver.FindElement(By.Id("username")).SendKeys(emailAddress);
        }

        public void Continue()
        {
            driver.FindElement(By.Id("LoginContinueBtn_1")).Click();
            Wait(10000); //could replace this with explicit wait like done earlier for review page load;
        }

        public void PopulaterAdultDetails(string title, string firstname, string lastname, string dobDay, string dobMonth, string dobYear, string mobilenumber)
        {
            new SelectElement(AdultTitle1).SelectByText(title);
            AdultFname1.SendKeys(firstname);
            AdultLname1.SendKeys(lastname);
            new SelectElement(AdultDobDay1).SelectByText(dobDay);
            new SelectElement(AdultDobMonth1).SelectByText(dobMonth);
            new SelectElement(AdultDobYear1).SelectByText(dobYear);
            MobileNumber.SendKeys(mobilenumber);
                                                               
        }

        public void PopulateChildDetails(string title, string firstname, string lastname, string dobDay, string dobMonth, string dobYear)
        {
            new SelectElement(ChildTitle1).SelectByText(title);
            ChildFname1.SendKeys(firstname);
            ChildLname1.SendKeys(lastname);
            new SelectElement(ChildDobDay1).SelectByText(dobDay);
            new SelectElement(ChildDobMonth1).SelectByText(dobMonth);
            new SelectElement(ChildDobYear1).SelectByText(dobYear);         
        }
    }
}
