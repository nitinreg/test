﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using AutomationCore.Enums;
using System.Configuration;
using System.Threading;

namespace AutomationCore.PageObjects
{
    public class PageBase
    {
        public static IWebDriver driver;

        public PageBase(Browsers browser)
        {
            if (driver == null)
            {
                driver = new Driver().GetDriver(browser);
                driver.Manage().Window.Maximize();
                driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromMilliseconds(10000);
            }
        }       

        public void Goto(string url)
        {
            if (!string.IsNullOrEmpty(url))
                 driver.Navigate().GoToUrl(url);
            else
                throw new Exception("Null or empty url");
        }

        public void Wait(int milliseconds)
        {
            Thread.Sleep(milliseconds);
        }

        public void Close()
        {
            driver.Close();
        }

        public void Quit()
        {
            driver.Quit();
        }
    }
}
