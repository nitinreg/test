﻿using System;
using TechTalk.SpecFlow;
using AutomationCore.PageObjects;
using AutomationCore.Enums;
using NUnit.Framework;
using System.Diagnostics;

namespace ClearTripTests
{
    [Binding]
    public class FlightBookingSteps
    {
        HomePage homePage = new HomePage(Browsers.Chrome);
        SearchResultsPage searchResultsPage = new SearchResultsPage(Browsers.Chrome);
        ReviewPage reviewPage = new ReviewPage(Browsers.Chrome);

        [Given(@"I am on Cleartrip website")]
        public void GivenIAmOnCleartripWebsite()
        {
            homePage.Load();
        }
        
        [Given(@"I enter origin as '(.*)' and destination as '(.*)' on the search page")]
        public void GivenIEnterOriginAsAndDestinationAsOnTheSearchPage(string origin, string destination)
        {
            homePage.SelectOrigin(origin);
        }


        [Given(@"I enter origin as '(.*)' on the search page")]
        public void GivenIEnterOriginAsOnTheSearchPage(string origin)
        {
            homePage.SelectOrigin(origin);
        }

        [Given(@"I enter destination as '(.*)' on the search page")]
        public void GivenIEnterDestinationAsOnTheSearchPage(string destination)
        {
            homePage.SelectDestination(destination);
        }


        [Given(@"I enter the departure date as '(.*)'")]
        public void GivenIEnterTheDepartureDateAs(string departureDate)
        {
            homePage.SelectDepartureDate(departureDate);
        }

        [Given(@"I select OneWay trip")]
        public void GivenISelectOneWayTrip()
        {
            homePage.SelectOneWayTrip();
        }


        [Given(@"I enter number of adults as (.*) and  number of children as (.*)")]
        public void GivenIEnterNumberOfAdultsAsAndNumberOfChildrenAs(int noOfAdults, int noOfChildren)
        {
            homePage.SelectNumberOfAdults(noOfAdults);
            homePage.SelectNumberOfChildren(noOfChildren);
        }

        [Given(@"I search for flights")]
        public void GivenISearchForFlights()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"I search for flights")]
        public void WhenISearchForFlights()
        {
            homePage.SearchFlights();
            searchResultsPage.WaitForResults();
        }

        [When(@"Sort the price of flights in ascending order")]
        public void WhenSortThePriceOfFlightsInAscendingOrder()
        {
            searchResultsPage.SortPriceAsc();
        }

        
        [When(@"book the most expensive flight")]
        public void WhenBookTheMostExpensiveFlight()
        {
            ScenarioContext.Current.Pending();
        }         

        [Then(@"The first price displayed is the cheapest price")]
        public void ThenTheFirstPriceDisplayedIsTheCheapestPrice()
        {
            Assert.That(searchResultsPage.FirstPrice(), Is.EqualTo(searchResultsPage.CheapestPrice()));
        }        

        [Then(@"I print the cheapest price")]
        public void ThenIPrintTheCheapestPrice()
        {
            var cheapestPrice = searchResultsPage.CheapestPrice().ToString();
            Debug.WriteLine("CheapestPrice is " + searchResultsPage.CheapestPrice().ToString());
            ScenarioContext.Current["CheapestFlightPrice"] =  cheapestPrice;
        }
        
        [Then(@"I save the cheapest price in excel file")]
        public void ThenISaveTheCheapestPriceInExcelFile()
        {
            //new ExcelHelper().SaveCheapestPriceToExcel(ScenarioContext.Current["CheapestFlightPrice"].ToString());
        }

        [Then(@"I book the most expensive flight")]
        public void ThenIBookTheMostExpensiveFlight()
        {
            searchResultsPage.BookMostExpensiveFlight();
        }


        [Then(@"I am taken to Review flight details page")]
        public void ThenIAmTakenToReviewFlightDetailsPage()
        {
            Assert.That(reviewPage.HasLoaded(), Is.EqualTo(true));
        }

        [Then(@"I continue booking")]
        public void ThenContinueBooking()
        {
            reviewPage.ContinueBooking();
        }

        [Then(@"I enter the email details (.*)")]
        public void ThenIEnterTheEmailDetails(string emailAddress)
        {
            reviewPage.EnterEmailAddress(emailAddress);
        }

        [Then(@"I click continue")]
        public void ThenIClickContinue()
        {
            reviewPage.Continue();
        }

        [Then(@"I enter traveller details")]
        public void ThenIEnterTravellerDetails()
        {
            reviewPage.PopulaterAdultDetails("Mr", "Abcd", "xyz", "1", "Jan", "1980", "9876598765");
            reviewPage.PopulateChildDetails("Mstr", "childA", "xyz", "1", "Dec", "2010");
        }

        [AfterScenario]
        public void TearDown()
        {
            reviewPage.Wait(5000); //can be removed, just added for demo so that the test doesn't close immediately after entering details on review page.
            //close and quit the webdriver instance
            reviewPage.Close(); //BasePage has close() and quit() methods, so can be called from anypage.
            reviewPage.Quit();
        }
    }
}
