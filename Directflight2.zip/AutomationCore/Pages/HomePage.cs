﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using AutomationCore.Enums;
using OpenQA.Selenium;
using OpenQA.Selenium.Support;
using OpenQA.Selenium.Support.UI;

namespace AutomationCore.Pages
{
    public class HomePage
    {
        private IWebDriver driver;
        public HomePage(Browsers browser)
        {
            driver = Driver.GetDriver(browser);
        }

        public IWebDriver GetDriver()
        {
            return driver;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="departingFrom"></param>
        /// <param name="destination"></param>
        /// <param name="datefrom"></param>
        /// <param name="returnDate"></param>
        public void SearchFlights(string departingFrom, string destination, DateTime datefrom, DateTime returnDate)
        {
            IWebElement elementFlightFrom = driver.FindElement(By.Id("txtFrom"));
            elementFlightFrom.Clear();
            elementFlightFrom.SendKeys(departingFrom); //todo put this in some app.config file
                                                       //also how to select from drop down

            //System.Threading.Thread.Sleep(4000);

            IWebElement airportFromUL = driver.FindElement(By.Id("ui-id-1"));
            //List<IWebElement> airportList
            var airportFromList = airportFromUL.FindElements(By.TagName("li"));
            foreach (IWebElement li in airportFromList)
            {
                if (li.Text.Contains(departingFrom))
                {
                    li.Click();
                }
            }                        

            IWebElement elementFlightTo = driver.FindElement(By.Id("txtTo"));
            elementFlightTo.Clear();
            elementFlightTo.SendKeys(destination);
           // System.Threading.Thread.Sleep(1000); //change with implicit wait for the control to appear etcetra
            IWebElement airportToUL = driver.FindElement(By.Id("ui-id-3"));
            var airportToList = airportToUL.FindElements(By.TagName("li"));
            foreach (IWebElement li in airportToList)
            {
                if (li.Text.Contains(destination))
                {
                    li.Click();
                }
            }

            //select calendar dates

            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            js.ExecuteScript("document.getElementById('flights_calendar_depart_inp_org').value='2018-10-10'");
            driver.FindElement(By.CssSelector("i[class= 'icon calendar_depart']")).Click();

            js.ExecuteScript("document.getElementById('flights_calendar_return_inp_org').value='2018-10-12'");
            driver.FindElement(By.CssSelector("i[class='icon calendar_return']")).Click();

            elementFlightTo.Submit();

          //  System.Threading.Thread.Sleep(41000); //Todo change with implicit wait etc

            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
            wait.Until(ExpectedConditions.ElementIsVisible(By.CssSelector("li[class='cheapest resp-tab-item resp-tab-active']")));
            //wait.Until(ExpectedConditions.ElementToBeClickable(Password));


            // frameork - https://www.swtestacademy.com/page-object-model-c/


        }

        //public void PrintOnPage(string text)
        //{
        //    IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
        //    //js.ExecuteScript("document.Write(" + text +"");           
        //    js.ExecuteScript("document.getElementById('flights_calendar_return_inp_org').value='2018-10-12'"
        //}


        /// <summary>
        /// Loads the website
        /// </summary>
        public void Load()
        {
            //driver.Url = "http://www.directflights.com";
            driver.Url = ConfigurationManager.AppSettings["baseUrl"].ToString();
        }

        public void Close()
        {
            driver.Close();
        }

        public void Quit()
        {
            driver.Quit();
        }     
       }    
    }